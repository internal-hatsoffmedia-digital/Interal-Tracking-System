import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    name: "Ek Adhoori Kahani",
    client: "Dashverse",
    progress: 78,
    status: "On Track",
    statusType: "green",
  },
  {
    name: "SDC Testimonial Series",
    client: "SDC",
    progress: 61,
    status: "At Risk",
    statusType: "orange",
  },
  {
    name: "L Band Campaign",
    client: "Color Pencil TV",
    progress: 43,
    status: "Delayed",
    statusType: "red",
  },
  {
    name: "Langhar Social Campaign",
    client: "Langhar Rice",
    progress: 86,
    status: "On Track",
    statusType: "green",
  },
];

function statusClasses(type: string) {
  if (type === "green") {
    return "bg-emerald-50 text-emerald-700 ring-emerald-600/10";
  }

  if (type === "orange") {
    return "bg-amber-50 text-amber-700 ring-amber-600/10";
  }

  return "bg-red-50 text-red-700 ring-red-600/10";
}

function ActiveProjects() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
        <div>
          <h2 className="font-semibold text-slate-950">
            Active Projects
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Projects currently in production.
          </p>
        </div>

        <button className="flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-slate-950">
          View all
          <ArrowUpRight size={15} />
        </button>
      </div>

      <div className="divide-y divide-slate-100">
        {projects.map((project) => (
          <div
            key={project.name}
            className="px-6 py-5 transition hover:bg-slate-50"
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  {project.name}
                </p>

                <p className="mt-1 text-xs text-slate-500">
                  {project.client}
                </p>
              </div>

              <span
                className={`w-fit rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${statusClasses(
                  project.statusType,
                )}`}
              >
                {project.status}
              </span>
            </div>

            <div className="mt-4 flex items-center gap-4">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100">
                <div
                  className="h-full rounded-full bg-slate-900"
                  style={{
                    width: `${project.progress}%`,
                  }}
                />
              </div>

              <span className="w-10 text-right text-xs font-semibold text-slate-600">
                {project.progress}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ActiveProjects;