function ProjectHealth() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-semibold text-slate-950">
            Project Health
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Current health across active projects.
          </p>
        </div>

        <button className="text-sm font-medium text-slate-600 hover:text-slate-950">
          View all
        </button>
      </div>

      <div className="mt-6 space-y-4">
        <HealthRow
          label="On Track"
          value="12"
          className="bg-emerald-500"
        />

        <HealthRow
          label="At Risk"
          value="4"
          className="bg-amber-500"
        />

        <HealthRow
          label="Delayed"
          value="2"
          className="bg-red-500"
        />

        <div className="border-t border-slate-100 pt-5">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-600">
              Total Active Projects
            </span>

            <span className="text-xl font-semibold text-slate-950">
              18
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

interface HealthRowProps {
  label: string;
  value: string;
  className: string;
}

function HealthRow({
  label,
  value,
  className,
}: HealthRowProps) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <span className={`h-2.5 w-2.5 rounded-full ${className}`} />

        <span className="text-sm text-slate-600">
          {label}
        </span>
      </div>

      <span className="text-sm font-semibold text-slate-950">
        {value}
      </span>
    </div>
  );
}

export default ProjectHealth;