import { ArrowUpRight } from "lucide-react";

const tasks = [
  {
    title: "Ek Adhoori Kahani — Episode 6",
    client: "Dashverse",
    artist: "Prasanth",
    due: "Today, 5:00 PM",
    status: "In Progress",
    type: "blue",
  },
  {
    title: "SDC Testimonial — Final Cut",
    client: "SDC",
    artist: "Saraswathy",
    due: "Today, 4:00 PM",
    status: "Internal Review",
    type: "purple",
  },
  {
    title: "L Band — Promo Edit",
    client: "Color Pencil TV",
    artist: "Rajasekar",
    due: "Overdue",
    status: "Blocked",
    type: "red",
  },
  {
    title: "Langhar — Reel 08",
    client: "Langhar Rice",
    artist: "Keerthana",
    due: "Tomorrow, 11:00 AM",
    status: "In Progress",
    type: "blue",
  },
];

function statusClasses(type: string) {
  if (type === "red") {
    return "bg-red-50 text-red-700 ring-red-600/10";
  }

  if (type === "purple") {
    return "bg-violet-50 text-violet-700 ring-violet-600/10";
  }

  return "bg-blue-50 text-blue-700 ring-blue-600/10";
}

function AttentionTasks() {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-col gap-3 border-b border-slate-100 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-semibold text-slate-950">
            Tasks Requiring Attention
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Tasks that need action from the coordinator or admin.
          </p>
        </div>

        <button className="text-sm font-medium text-slate-600 hover:text-slate-950">
          View all tasks
        </button>
      </div>

      <div className="hidden overflow-x-auto md:block">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100 text-left">
              <th className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Task
              </th>

              <th className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Client
              </th>

              <th className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Artist
              </th>

              <th className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Due
              </th>

              <th className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Status
              </th>

              <th />
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {tasks.map((task) => (
              <tr key={task.title} className="hover:bg-slate-50">
                <td className="px-6 py-4">
                  <p className="max-w-xs truncate text-sm font-medium text-slate-900">
                    {task.title}
                  </p>
                </td>

                <td className="px-6 py-4 text-sm text-slate-600">
                  {task.client}
                </td>

                <td className="px-6 py-4 text-sm text-slate-600">
                  {task.artist}
                </td>

                <td
                  className={`px-6 py-4 text-sm ${
                    task.due === "Overdue"
                      ? "font-semibold text-red-600"
                      : "text-slate-600"
                  }`}
                >
                  {task.due}
                </td>

                <td className="px-6 py-4">
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${statusClasses(
                      task.type,
                    )}`}
                  >
                    {task.status}
                  </span>
                </td>

                <td className="px-6 py-4 text-right">
                  <button className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
                    <ArrowUpRight size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="divide-y divide-slate-100 md:hidden">
        {tasks.map((task) => (
          <div key={task.title} className="space-y-3 px-6 py-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  {task.title}
                </p>

                <p className="mt-1 text-xs text-slate-500">
                  {task.client} · {task.artist}
                </p>
              </div>

              <ArrowUpRight
                size={16}
                className="shrink-0 text-slate-400"
              />
            </div>

            <div className="flex items-center justify-between">
              <span
                className={`rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${statusClasses(
                  task.type,
                )}`}
              >
                {task.status}
              </span>

              <span
                className={`text-xs ${
                  task.due === "Overdue"
                    ? "font-semibold text-red-600"
                    : "text-slate-500"
                }`}
              >
                {task.due}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default AttentionTasks;