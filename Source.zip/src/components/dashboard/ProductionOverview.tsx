import { Timer } from "lucide-react";

const stages = [
  {
    label: "In Progress",
    value: 8,
    percentage: 67,
  },
  {
    label: "Internal Review",
    value: 5,
    percentage: 42,
  },
  {
    label: "Client Review",
    value: 3,
    percentage: 25,
  },
  {
    label: "Completed",
    value: 8,
    percentage: 67,
  },
];

function ProductionOverview() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-semibold text-slate-950">
            Today&apos;s Production
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Current task distribution across production.
          </p>
        </div>

        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
          <Timer size={18} className="text-slate-700" />
        </div>
      </div>

      <div className="mt-7 space-y-5">
        {stages.map((stage) => (
          <div key={stage.label}>
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">
                {stage.label}
              </span>

              <span className="font-semibold text-slate-950">
                {stage.value}
              </span>
            </div>

            <div className="h-2 overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full bg-slate-900 transition-all"
                style={{
                  width: `${stage.percentage}%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductionOverview;