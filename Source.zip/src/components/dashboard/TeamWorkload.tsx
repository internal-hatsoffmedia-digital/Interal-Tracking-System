import { Users } from "lucide-react";

const team = [
  {
    name: "Prasanth",
    role: "Cut Masters",
    hours: "7.2h",
    capacity: 90,
  },
  {
    name: "Saraswathy",
    role: "Creative Clan",
    hours: "6.5h",
    capacity: 81,
  },
  {
    name: "Rajasekar",
    role: "Cut Masters",
    hours: "8.4h",
    capacity: 100,
  },
  {
    name: "Keerthana",
    role: "Digital Ninjas",
    hours: "5.8h",
    capacity: 72,
  },
];

function TeamWorkload() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-start justify-between border-b border-slate-100 px-6 py-5">
        <div>
          <h2 className="font-semibold text-slate-950">
            Team Workload
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Today&apos;s estimated capacity.
          </p>
        </div>

        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100">
          <Users size={17} className="text-slate-700" />
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {team.map((person) => (
          <div key={person.name} className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-slate-700">
                  {person.name.charAt(0)}
                </div>

                <div>
                  <p className="text-sm font-medium text-slate-900">
                    {person.name}
                  </p>

                  <p className="text-xs text-slate-500">
                    {person.role}
                  </p>
                </div>
              </div>

              <span className="text-sm font-semibold text-slate-700">
                {person.hours}
              </span>
            </div>

            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full bg-slate-700"
                style={{
                  width: `${person.capacity}%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TeamWorkload;