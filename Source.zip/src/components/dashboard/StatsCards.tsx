import {
  AlertTriangle,
  CheckCircle2,
  FolderKanban,
  PlayCircle,
} from "lucide-react";

const stats = [
  {
    label: "Total Tasks",
    value: "24",
    change: "+8%",
    description: "vs yesterday",
    icon: FolderKanban,
  },
  {
    label: "In Progress",
    value: "08",
    change: "04 active",
    description: "being worked on",
    icon: PlayCircle,
  },
  {
    label: "In Review",
    value: "05",
    change: "02 urgent",
    description: "awaiting review",
    icon: CheckCircle2,
  },
  {
    label: "At Risk",
    value: "05",
    change: "03 blocked",
    description: "needs attention",
    icon: AlertTriangle,
  },
];

function StatsCards() {
  return (
    <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon;

        return (
          <div
            key={stat.label}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700">
              <Icon size={19} strokeWidth={1.8} />
            </div>

            <div className="mt-5">
              <p className="text-sm text-slate-500">
                {stat.label}
              </p>

              <div className="mt-1 flex items-end gap-2">
                <span className="text-3xl font-semibold tracking-tight text-slate-950">
                  {stat.value}
                </span>

                <span className="mb-1 text-xs font-medium text-emerald-600">
                  {stat.change}
                </span>
              </div>

              <p className="mt-1 text-xs text-slate-400">
                {stat.description}
              </p>
            </div>
          </div>
        );
      })}
    </section>
  );
}

export default StatsCards;