import ActiveProjects from "../../components/dashboard/ActiveProjects";
import AttentionTasks from "../../components/dashboard/AttentionTasks";
import DashboardHeader from "../../components/dashboard/DashboardHeader";
import ProductionAlert from "../../components/dashboard/ProductionAlert";
import ProductionOverview from "../../components/dashboard/ProductionOverview";
import ProjectHealth from "../../components/dashboard/ProjectHealth";
import StatsCards from "../../components/dashboard/StatsCards";
import TeamWorkload from "../../components/dashboard/TeamWorkload";

function Dashboard() {
  return (
    <div>
      <DashboardHeader />

      <div className="space-y-5">
        <StatsCards />

        <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
          <ProductionOverview />
          <ProjectHealth />
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
          <ActiveProjects />
          <TeamWorkload />
        </div>

        <AttentionTasks />

        <ProductionAlert />
      </div>
    </div>
  );
}

export default Dashboard;