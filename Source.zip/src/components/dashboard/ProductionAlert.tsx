import {
  ArrowUpRight,
  Users,
} from "lucide-react";

function ProductionAlert() {
  return (
    <section className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-slate-950 p-6 text-white sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-start gap-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10">
          <Users size={19} />
        </div>

        <div>
          <p className="font-semibold">
            Production capacity looks healthy.
          </p>

          <p className="mt-1 text-sm text-slate-400">
            3 tasks are currently blocked and require coordinator attention.
          </p>
        </div>
      </div>

      <button className="flex items-center gap-2 text-sm font-medium text-white hover:text-slate-300">
        Review blockers
        <ArrowUpRight size={16} />
      </button>
    </section>
  );
}

export default ProductionAlert;