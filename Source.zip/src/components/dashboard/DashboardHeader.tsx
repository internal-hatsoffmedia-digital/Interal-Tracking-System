import { ArrowUpRight, Zap } from "lucide-react";

function DashboardHeader() {
  return (
    <section className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div>
        <div className="mb-2 flex items-center gap-2 text-sm text-slate-400">
          <span>Workspace</span>
          <span>/</span>
          <span className="text-slate-600">Dashboard</span>
        </div>

        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">
          Good afternoon, Vijay.
        </h1>

        <p className="mt-1 text-sm text-slate-500">
          Here&apos;s what&apos;s happening across production today.
        </p>
      </div>

      <div className="flex items-center gap-3">
        <button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 shadow-sm transition hover:border-slate-300 hover:bg-slate-50">
          View Reports
          <ArrowUpRight size={15} />
        </button>

        <button className="flex items-center gap-2 rounded-xl bg-slate-950 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-slate-800">
          <Zap size={16} />
          Quick Action
        </button>
      </div>
    </section>
  );
}

export default DashboardHeader;