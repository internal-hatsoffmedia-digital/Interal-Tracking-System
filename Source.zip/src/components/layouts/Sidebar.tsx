import {
  BarChart3,
  CalendarDays,
  CheckSquare,
  ChevronRight,
  ClipboardList,
  FolderKanban,
  LayoutDashboard,
  Settings,
  Timer,
  Users,
  UserRound,
  BriefcaseBusiness,
} from "lucide-react";
import { NavLink } from "react-router-dom";

const navigation = [
  {
    label: "Dashboard",
    path: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    label: "My Work",
    path: "/my-work",
    icon: CheckSquare,
  },
  {
    label: "Tasks",
    path: "/tasks",
    icon: ClipboardList,
  },
  {
    label: "Planner",
    path: "/planner",
    icon: CalendarDays,
  },
  {
    label: "Timesheet",
    path: "/timesheet",
    icon: Timer,
  },
  {
    label: "Projects",
    path: "/projects",
    icon: FolderKanban,
  },
  {
    label: "Clients",
    path: "/clients",
    icon: BriefcaseBusiness,
  },
  {
    label: "Teams",
    path: "/teams",
    icon: Users,
  },
  {
    label: "Employees",
    path: "/employees",
    icon: UserRound,
  },
  {
    label: "Performance",
    path: "/performance",
    icon: BarChart3,
  },
];

function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-slate-200 bg-white lg:flex lg:flex-col">
      {/* Brand */}
      <div className="flex h-20 items-center border-b border-slate-200 px-6">
        <div>
          <div className="text-lg font-bold tracking-tight text-slate-950">
            HATSOFF
          </div>

          <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-slate-400">
            Internal Force
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 overflow-y-auto p-4">
        <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400">
          Workspace
        </p>

        {navigation.map((item) => {
          const Icon = item.icon;

          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                [
                  "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                  isActive
                    ? "bg-slate-900 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-950",
                ].join(" ")
              }
            >
              {({ isActive }) => (
                <>
                  <Icon size={18} strokeWidth={1.8} />

                  <span className="flex-1">{item.label}</span>

                  {isActive && <ChevronRight size={15} />}
                </>
              )}
            </NavLink>
          );
        })}

        <div className="my-5 border-t border-slate-100" />

        <NavLink
          to="/reports"
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-950"
        >
          <BarChart3 size={18} strokeWidth={1.8} />
          Reports
        </NavLink>

        <NavLink
          to="/settings"
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-950"
        >
          <Settings size={18} strokeWidth={1.8} />
          Settings
        </NavLink>
      </nav>

      {/* User */}
      <div className="border-t border-slate-200 p-4">
        <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-900 text-xs font-semibold text-white">
            V
          </div>

          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-900">
              Vijay
            </p>

            <p className="text-xs text-slate-500">
              Internal User
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;