import {
  Bell,
  Search,
  Menu,
} from "lucide-react";

function Topbar() {
  return (
    <header className="sticky top-0 z-30 flex h-20 items-center justify-between border-b border-slate-200 bg-white/90 px-6 backdrop-blur lg:px-8">
      {/* Mobile */}
      <button className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden">
        <Menu size={20} />
      </button>

      {/* Search */}
      <div className="hidden w-full max-w-md lg:block">
        <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5">
          <Search size={17} className="text-slate-400" />

          <input
            type="text"
            placeholder="Search tasks, projects, clients..."
            className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"
          />

          <kbd className="hidden rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[10px] text-slate-400 xl:block">
            Ctrl K
          </kbd>
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        <button className="relative rounded-xl p-2.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900">
          <Bell size={19} />

          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-red-500" />
        </button>

        <div className="hidden h-8 w-px bg-slate-200 sm:block" />

        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-900 text-xs font-semibold text-white">
            V
          </div>

          <div className="hidden sm:block">
            <p className="text-sm font-semibold text-slate-900">
              Vijay
            </p>

            <p className="text-xs text-slate-500">
              Internal User
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Topbar;