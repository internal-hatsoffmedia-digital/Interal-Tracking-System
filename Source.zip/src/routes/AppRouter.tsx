import { Navigate, Route, Routes } from "react-router-dom";
import AppShell from "../components/layouts/AppShell";
import Dashboard from "../components/dashboard/Dashboard";
import Landing from "../pages/landing/Landing";
import Login from "../pages/auth/Login";

function AppRouter() {
  return (
    <Routes>
      {/* Public Pages */}
      <Route path="/" element={<Landing />} />

      <Route path="/login" element={<Login />} />

      {/* Internal Application */}
      <Route element={<AppShell />}>
        <Route path="/dashboard" element={<Dashboard />} />
      </Route>

      {/* Fallback */}
      <Route
        path="*"
        element={<Navigate to="/" replace />}
      />
    </Routes>
  );
}

export default AppRouter;